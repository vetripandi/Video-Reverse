# ViMax
Android Video Editing Application build on top of FFmpeg. 
Just playing around.

## Dependencies
* [FFmpeg-Android-Java](https://github.com/WritingMinds/ffmpeg-android-java)
* [Dagger 2](https://github.com/google/dagger)
* [RxJava 2](https://github.com/ReactiveX/RxJava/wiki/What's-different-in-2.0)
* [Glide](https://github.com/bumptech/glide)
* [Butterknife](https://github.com/JakeWharton/butterknife)
