package com.kavithapandian.videoreverse.ui.base;

public interface BaseView {
    void showToastMessage(String message, int length);
}
