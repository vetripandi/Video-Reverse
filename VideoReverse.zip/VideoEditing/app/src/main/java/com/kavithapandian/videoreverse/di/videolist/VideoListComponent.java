package com.kavithapandian.videoreverse.di.videolist;

import com.kavithapandian.videoreverse.ui.videolist.VideoFragment;

import dagger.Subcomponent;

@Subcomponent(modules = {VideoListModule.class})
public interface VideoListComponent {
    void inject(VideoFragment fragment);
}
