package com.kavithapandian.videoreverse.ui.videolist;

import android.content.Context;
import android.content.Intent;

import com.kavithapandian.videoreverse.data.model.Video;
import com.kavithapandian.videoreverse.ui.base.BaseFragmentView;
import com.kavithapandian.videoreverse.ui.base.BasePresenter;

import java.util.List;

public interface VideoContract {
    interface View extends BaseFragmentView {
        void showVideos(List<Video> listVideo);
        void showCurrentVideosWithOptions(String option);
        void showProgressCircle();
        void hideProgressCircle();
        void showBackOnTopButton();
        void hideBackOnTopButton();
        void scrollOnTop();
    }

    interface Presenter extends BasePresenter<View> {
        void getVideos(Context ctx);
        void setCheckAll(List<Video> listVideo);
        void setUncheckAll(List<Video> listVideo);
        void returnToInitialState(VideoAdapter adapter);
        boolean enableAllCheckBox(VideoAdapter adapter, int position);
        void deleteCheckedVideos(List<Video> listVideo);
        void checkVideo(Video video);
        void onReceiveAction(Context context, Intent intent);
        void onListScroll(int lastVisiblePosition, int listSize, int dx, int dy);
        void onBtnBackOnTopClicked();
        void searchVideo(String query);
        void showCurrentVideosWithOptions(List<Video> listCurrentVideos, String option);
    }

    interface VideoItemListener {
        void onCheckClick(int position);
    }
}
