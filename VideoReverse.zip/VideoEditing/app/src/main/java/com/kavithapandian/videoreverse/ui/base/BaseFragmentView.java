package com.kavithapandian.videoreverse.ui.base;

public interface BaseFragmentView extends BaseView {
    void showHiddenLayout();
    void hideHiddenLayout();
}
