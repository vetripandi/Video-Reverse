package com.kavithapandian.videoreverse.di.albumlist;


import com.kavithapandian.videoreverse.data.OfflineVideoAlbumRepository;
import com.kavithapandian.videoreverse.data.OfflineVideoRepository;
import com.kavithapandian.videoreverse.ui.albumlist.AlbumContract;
import com.kavithapandian.videoreverse.ui.albumlist.AlbumPresenter;

import dagger.Module;
import dagger.Provides;
import io.reactivex.disposables.CompositeDisposable;

@Module
public class AlbumListModule {

    @Provides
    AlbumContract.Presenter albumPresenter(OfflineVideoAlbumRepository offlineVideoAlbumRepository,
                                           OfflineVideoRepository offlineVideoRepository,
                                           CompositeDisposable disposable) {
        return new AlbumPresenter(offlineVideoAlbumRepository, offlineVideoRepository, disposable);
    }
}
