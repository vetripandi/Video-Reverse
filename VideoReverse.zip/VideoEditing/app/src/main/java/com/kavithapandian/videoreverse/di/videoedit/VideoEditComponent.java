package com.kavithapandian.videoreverse.di.videoedit;

import com.kavithapandian.videoreverse.ui.videoedit.VideoEditActivity;

import dagger.Subcomponent;

@Subcomponent(modules = {VideoEditModule.class})
public interface VideoEditComponent {
    void inject(VideoEditActivity videoEditActivity);
}
