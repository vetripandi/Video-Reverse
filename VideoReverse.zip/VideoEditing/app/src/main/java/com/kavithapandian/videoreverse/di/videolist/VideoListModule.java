package com.kavithapandian.videoreverse.di.videolist;

import com.kavithapandian.videoreverse.data.OfflineVideoRepository;
import com.kavithapandian.videoreverse.ui.videolist.VideoContract;
import com.kavithapandian.videoreverse.ui.videolist.VideoPresenter;


import dagger.Module;
import dagger.Provides;
import io.reactivex.disposables.CompositeDisposable;

@Module
public class VideoListModule {

    @Provides
    VideoContract.Presenter videoPresenter(OfflineVideoRepository offlineVideoRepository
            , CompositeDisposable compositeDisposable) {
        return new VideoPresenter(offlineVideoRepository, compositeDisposable);
    }
}
