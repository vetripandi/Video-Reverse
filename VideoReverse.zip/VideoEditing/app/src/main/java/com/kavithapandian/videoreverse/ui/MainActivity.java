package com.kavithapandian.videoreverse.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import com.kavithapandian.videoreverse.DummyFragment;
import com.kavithapandian.videoreverse.R;
import com.kavithapandian.videoreverse.ViMaxApplication;
import com.kavithapandian.videoreverse.ui.videolist.VideoFragment;
import com.kavithapandian.videoreverse.utils.AppConstants;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.disposables.CompositeDisposable;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class MainActivity extends AppCompatActivity {
    private AdView mAdView;
    @BindView(R.id.searchView)
    SearchView searchView;
    @BindView(R.id.mainTab)
    TabLayout mainTab;
    @BindView(R.id.mainPager)
    ViewPager mainPager;
    @BindView(R.id.toolbar)
    Toolbar toolbar;

    MainPagerAdapter adapter;
    CompositeDisposable compositeDisposable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MobileAds.initialize(this, "ca-app-pub-3940256099942544~3347511713");
        mAdView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        ButterKnife.bind(this);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(null);

        setUpPager(mainPager);
        mainTab.setupWithViewPager(mainPager);

        compositeDisposable = ((ViMaxApplication)getApplication()).getApplicationComponent().getCompositeDisposable();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) { return false; }

            @Override
            public boolean onQueryTextChange(String newText) {
                Intent i = new Intent(AppConstants.ACION_SEARCH);
                i.putExtra(AppConstants.EXTRA_SEARCH_QUERY, newText);
                LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(i);
                return true;
            }
        });
    }

    private void setUpPager(ViewPager mainPager) {
        adapter = new MainPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new DummyFragment(), "Album");
        adapter.addFragment(new VideoFragment(), "Video");
        mainPager.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    protected void onResume() {
        // Disable default focusing
        searchView.setFocusable(false);
        searchView.setIconified(false);
        searchView.clearFocus();
        super.onResume();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_sort_asc:
                Intent iAsc = new Intent(AppConstants.ACTION_SORT_ASC);
                LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(iAsc);
                return true;
            case R.id.action_sort_desc:
                Intent iDesc = new Intent(AppConstants.ACTION_SORT_DESC);
                LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(iDesc);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private class MainPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> fragmentList = new ArrayList<>();
        private final List<String> fragmentTitleList = new ArrayList<>();

        MainPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            return fragmentList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }

        void addFragment(Fragment fragment, String title) {
            fragmentList.add(fragment);
            fragmentTitleList.add(title);
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            return fragmentTitleList.get(position);
        }
    }

}
