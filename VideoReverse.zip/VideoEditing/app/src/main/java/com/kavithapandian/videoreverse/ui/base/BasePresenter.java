package com.kavithapandian.videoreverse.ui.base;

public interface BasePresenter <T extends BaseView> {
    void setView(T view);
    void destroy();
}
