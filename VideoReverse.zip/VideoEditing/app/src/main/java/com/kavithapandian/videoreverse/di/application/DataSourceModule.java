package com.kavithapandian.videoreverse.di.application;

import com.kavithapandian.videoreverse.data.OfflineVideoAlbumRepository;
import com.kavithapandian.videoreverse.data.OfflineVideoRepository;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
public class DataSourceModule {
    @Singleton
    @Provides
    OfflineVideoRepository offlineVideoRepository() {
        return new OfflineVideoRepository();
    }

    @Singleton
    @Provides
    OfflineVideoAlbumRepository offlineVideoAlbumRepository() {
        return new OfflineVideoAlbumRepository();
    }
}
