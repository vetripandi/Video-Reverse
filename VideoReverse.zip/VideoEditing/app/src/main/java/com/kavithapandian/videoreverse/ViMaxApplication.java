package com.kavithapandian.videoreverse;

import android.app.Application;
import android.widget.Toast;

import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.LoadBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegNotSupportedException;
import com.kavithapandian.videoreverse.di.albumlist.AlbumListComponent;
import com.kavithapandian.videoreverse.di.albumlist.AlbumListModule;
import com.kavithapandian.videoreverse.di.application.ApplicationComponent;
import com.kavithapandian.videoreverse.di.application.ApplicationModule;
import com.kavithapandian.videoreverse.di.application.DataSourceModule;
import com.kavithapandian.videoreverse.di.application.FfmpegModule;
import com.kavithapandian.videoreverse.di.application.DaggerApplicationComponent;
import com.kavithapandian.videoreverse.di.videoedit.VideoEditComponent;
import com.kavithapandian.videoreverse.di.videoedit.VideoEditModule;
import com.kavithapandian.videoreverse.di.videolist.VideoListComponent;
import com.kavithapandian.videoreverse.di.videolist.VideoListModule;
import com.kavithapandian.videoreverse.ui.videoedit.VideoEditContract;

import javax.inject.Inject;

public class ViMaxApplication extends Application {
    ApplicationComponent applicationComponent;
    VideoListComponent videoListComponent;
    AlbumListComponent albumListComponent;
    VideoEditComponent videoEditComponent;
    @Inject
    FFmpeg ffmpeg;
    @Override
    public void onCreate() {
        super.onCreate();
        applicationComponent = createAppComponent();
        applicationComponent.inject(this);
        loadFfmpegBinary();
    }

    private ApplicationComponent createAppComponent() {
        return DaggerApplicationComponent
                .builder()
                .applicationModule(new ApplicationModule(this))
                .ffmpegModule(new FfmpegModule())
                .dataSourceModule(new DataSourceModule())
                .build();
    }

    private void loadFfmpegBinary() {
        try {
            ffmpeg.loadBinary(new LoadBinaryResponseHandler() {

                @Override
                public void onStart() {
                }

                @Override
                public void onFailure() {}

                @Override
                public void onSuccess() {
                    Toast.makeText(getApplicationContext(), "FFmpeg loaded successfully", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onFinish() {}
            });
        } catch (FFmpegNotSupportedException e) {
            // Handle if FFmpeg is not supported by device
            Toast.makeText(getApplicationContext(), "FFmpeg not supported", Toast.LENGTH_SHORT).show();
        }
    }

    public FFmpeg getFfmpegInstance() {
        return this.ffmpeg;
    }

    public ApplicationComponent getApplicationComponent() {
        return applicationComponent;
    }

    public VideoListComponent createVideoListComponent() {
        videoListComponent = applicationComponent.plus(new VideoListModule());
        return videoListComponent;
    }

    public AlbumListComponent createAlbumListComponent() {
        albumListComponent = applicationComponent.plus(new AlbumListModule());
        return albumListComponent;
    }

    public VideoEditComponent createVideoEditComponent(VideoEditContract.View view) {
        videoEditComponent = applicationComponent.plus(new VideoEditModule(view));
        return videoEditComponent;
    }

    public void releaseVideoListComponent() {
        videoListComponent = null;
    }

    public void releaseAlbumListComponent() {
        albumListComponent = null;
    }

    public void releaseVideoEditComponent() {
        videoEditComponent = null;
    }
}