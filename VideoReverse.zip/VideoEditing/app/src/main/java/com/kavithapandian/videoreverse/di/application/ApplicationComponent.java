package com.kavithapandian.videoreverse.di.application;

import com.kavithapandian.videoreverse.ViMaxApplication;
import com.kavithapandian.videoreverse.di.albumlist.AlbumListComponent;
import com.kavithapandian.videoreverse.di.albumlist.AlbumListModule;
import com.kavithapandian.videoreverse.di.videoedit.VideoEditComponent;
import com.kavithapandian.videoreverse.di.videoedit.VideoEditModule;
import com.kavithapandian.videoreverse.di.videolist.VideoListComponent;
import com.kavithapandian.videoreverse.di.videolist.VideoListModule;

import javax.inject.Singleton;

import dagger.Component;
import io.reactivex.disposables.CompositeDisposable;

@Singleton
@Component(modules = {ApplicationModule.class, FfmpegModule.class, DataSourceModule.class})
public interface ApplicationComponent {
    void inject(ViMaxApplication application);
    CompositeDisposable getCompositeDisposable();
    VideoListComponent plus(VideoListModule videoListModule);
    AlbumListComponent plus(AlbumListModule albumListModule);
    VideoEditComponent plus(VideoEditModule videoEditModule);
}
